# MeeshQuest
The Project for CMSC420
Arno Bischoff
bischoff

Resources:
Java Documentation
Ranking in Spatial Dimensions https://www.cs.umd.edu/users/meesh/420/ContentBook/FormalNotes/neighbornotes/incnear.pdf
Intersection between Line (Road) and point (center of circular range):
    https://en.wikipedia.org/wiki/Distance_from_a_point_to_a_line