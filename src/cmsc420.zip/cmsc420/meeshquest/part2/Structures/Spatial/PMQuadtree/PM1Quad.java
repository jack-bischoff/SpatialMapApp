package cmsc420.meeshquest.part2.Structures.Spatial.PMQuadtree;

public class PM1Quad {
}
