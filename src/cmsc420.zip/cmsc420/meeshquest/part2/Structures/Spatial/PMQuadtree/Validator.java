package cmsc420.meeshquest.part2.Structures.Spatial.PMQuadtree;

import cmsc420.meeshquest.part2.Structures.Spatial.PRQuadTree.Node;

public abstract class Validator {
    public abstract boolean validate(Node n);
}
