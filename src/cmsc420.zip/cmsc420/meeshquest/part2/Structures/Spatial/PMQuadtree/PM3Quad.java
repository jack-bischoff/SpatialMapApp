package cmsc420.meeshquest.part2.Structures.Spatial.PMQuadtree;

public class PM3Quad extends PMQuadtree{
    public PM3Quad(int width, int height) {
        super(width, height);
        this.type = "3";
    }
}
